export const environment = {
  production: true ,

  apiurl : "https://ancient-crag-75461.herokuapp.com/"

};
