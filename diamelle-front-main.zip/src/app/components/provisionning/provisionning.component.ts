import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-provisionning',
  templateUrl: './provisionning.component.html',
  styleUrls: ['./provisionning.component.css']
})
export class ProvisionningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
